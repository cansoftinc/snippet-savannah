Extensions for Vaadin Spring
============================

This directory contains extensions that extend or add features to Vaadin Spring add-on. Some of the extensions might
eventually end up in the official add-on, whereas some might remain in this project.
