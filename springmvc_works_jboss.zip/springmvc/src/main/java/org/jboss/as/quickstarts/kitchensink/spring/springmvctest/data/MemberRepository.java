/**
 * 
 */
package org.jboss.as.quickstarts.kitchensink.spring.springmvctest.data;

import org.jboss.as.quickstarts.kitchensink.spring.springmvctest.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author nyakundid
 *
 */
public interface MemberRepository extends JpaRepository<Member,Long>{

}
